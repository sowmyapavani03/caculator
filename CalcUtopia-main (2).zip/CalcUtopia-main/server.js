const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/scal', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB');
});

// Define a Schema for your data
const dataSchema = new mongoose.Schema({
  field1: String,
  field2: Number,
  // Add more fields as needed
});

// Create a model based on the schema
const Data = mongoose.model('Data', dataSchema);

// Middleware to parse JSON requests
app.use(bodyParser.json());

// API endpoint to handle storing data
app.post('/storeData', async (req, res) => {
  const dataToStore = req.body.data;

  try {
    // Create a new document using the Data model
    const newData = new Data({
      field1: dataToStore.field1,
      field2: dataToStore.field2,
      // Add more fields as needed
    });

    // Save the document to the database
    await newData.save();

    res.status(200).json({ success: true, message: 'Data stored successfully' });
  } catch (error) {
    console.error('Error storing data in MongoDB:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
